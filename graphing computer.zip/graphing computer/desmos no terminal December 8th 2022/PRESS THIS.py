#!/usr/bin/env python3
# import all classes/methods
from ast import Pass
from tkinter import * 
from tkinter import colorchooser
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg, 
NavigationToolbar2Tk)
import matplotlib.pyplot as plt
import numpy as np
import tkinter as tk
import re
import random
import time
import sys, os
import torch
import sqlite3
import io
import datetime
import decimal
from textwrap import wrap
from location import Location
import mpmath as mp
import gmpy2 as gp #this is the library that gives more detail

LIMIT = 50000
mp.mp.dps = 30
# number of points affects both the slow and the fast
# george aug30,2022 number of points 100 is fewer points, 200 is good average, 400 is finer and more points makes it go slower
# 3000 sines using 100=1min, 200=4.5min, 400 don't know
# 100 sines look on table in readme.md at the bottom
NUMBER_OF_POINTS = 500
# precision only used for the slow version, doesn't do anything for the fast version
# precision:100 = 32 decimals george aug30,2022 this changes the number of decimals any integer works
# precision:200 = 64 decimals
# precision:300 = 128 decimals
PRECISION = 100
gp.get_context().precision=PRECISION

MODE = "FAST"

def createFile(path):
    L = ["NUMBER_OF_POINTS=500\n", "PRECISION=100\n"]
    # Writing to a file
    file1 = open(path, 'w+')
    file1.writelines((L))
    file1.close()

def createDefaultPoint(path):
    global NUMBER_OF_POINTS, PRECISION
    createFile(path)
    NUMBER_OF_POINTS = 500
    PRECISION = 100
    return

def fetchNumberPoints(path):
    global NUMBER_OF_POINTS, PRECISION
    if os.path.exists(path) == False:
        createDefaultPoint(path)
        return

    numberFile = open(path, 'r')
    lines = numberFile.readlines()
    if len(lines) != 2:
        os.remove(path)
        createDefaultPoint(path)
        return
    pointRegex = re.compile(r'^NUMBER_OF_POINTS=\d+$')
    precisionRegex = re.compile(r'^PRECISION=\d+$')
    pointLine = lines[0].strip()
    precisionLine = lines[1].strip()
    if pointRegex.match(pointLine) == None or precisionRegex.match(precisionLine) == None:
        os.remove(path)  
        createDefaultPoint(path)
        return
    NUMBER_OF_POINTS = int(pointLine.split('=')[1])
    PRECISION = int(precisionLine.split('=')[1])

def representsFloat(s):
    try:
        float(s)
        return True
    except ValueError:
        return False
'''
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)
'''

def adapt_array(arr):
    """
    http://stackoverflow.com/a/31312102/190597 (SoulNibbler)
    """
    out = io.BytesIO()
    np.save(out, arr)
    out.seek(0)
    return sqlite3.Binary(out.read())

def convert_array(text):
    out = io.BytesIO(text)
    out.seek(0)
    return np.load(out, allow_pickle=True)

def create_db():
    print("os.path.dirname(os.path.abspath(__file__)) + '/database.db'")
    # Converts np.array to TEXT when inserting
    sqlite3.register_adapter(np.ndarray, adapt_array)

    # Converts TEXT to np.array when selecting
    sqlite3.register_converter("array", convert_array)
    con = sqlite3.connect(os.path.dirname(os.path.abspath(__file__)) + '/database.db', detect_types=sqlite3.PARSE_DECLTYPES, isolation_level=None)
    print(con)
    cur = con.cursor()
    # Create table
    cur.execute('''CREATE TABLE IF NOT EXISTS equations
                (torchequ text, xlow REAL, xhigh REAL, ylow REAL, yhigh REAL, result array, addtime timestamp, mode text, numpoint REAL, precision REAL)''')
    db_stats = os.stat(os.path.dirname(os.path.abspath(__file__)) + '/database.db')
    if db_stats.st_size / (1024 * 1024) >= 100:
        cur.execute("DELETE FROM equations WHERE ROWID IN (SELECT ROWID FROM equations ORDER BY ROWID ASC LIMIT 10)")
        cur.execute("vacuum")
    # Save (commit) the changes
    con.commit()
    return con

def set_text(e, text):
    e.delete(0,END)
    e.insert(0,text)
    return e
    
def centerZoom(centerX, centerY, ratio, inOut):
    global xStart, xEnd, yStart, yEnd
    xStartFloat = float(xStart.get())
    xEndFloat = float(xEnd.get())
    yStartFloat = float(yStart.get())
    yEndFloat = float(yEnd.get())
    if (inOut == "in"):
        newRatio = 1/(ratio*2)
    else:
        newRatio = ratio/2
    newXStart = centerX - (xEndFloat - xStartFloat)*newRatio*gp.mpfr(1)
    newXEnd = centerX + (xEndFloat - xStartFloat)*newRatio*gp.mpfr(1)
    newYStart = centerY - (yEndFloat - yStartFloat)*newRatio*gp.mpfr(1)
    newYEnd = centerY + (yEndFloat - yStartFloat)*newRatio*gp.mpfr(1)
    # print("newX: ")
    # print(str(newXStart))
    xStart = set_text(xStart, str(newXStart))
    xEnd = set_text(xEnd, str(newXEnd))
    yStart = set_text(yStart, str(newYStart))
    yEnd = set_text(yEnd, str(newYEnd))

def onclick(event):
    global xStart, xEnd, yStart, yEnd, ratioInput
    if event.dblclick:
        xdata = float(event.xdata)
        ydata = float(event.ydata)
        ratio = float(ratioInput.get())
        centerZoom(xdata, ydata, ratio, "in")
        plot()


def findCosSinEqu(matchings):
    listOperators = ["+", "(", ")", "-"]
    newEqu = ""
    count = 0
    for match in matchings:
        count += 1
        item = match.group(0)
        # add * before x
        indexofX = item.find("x")
        if indexofX > 1 and item[indexofX-1] not in listOperators:
            item = item[:indexofX] + '*' + item[indexofX:]
        # add * before y
        indexofY = item.find("y")
        if indexofY > 1 and item[indexofY-1] not in listOperators:
            item = item[:indexofY] + '*' + item[indexofY:]
        # if there is coefficient before sin or cos
        if item[1] != "s" and item[1] != "c":
            indexofS = item.find("s")
            indexofC = item.find("c")
            # if it is sin items
            if indexofC == -1:
                indexofStart = indexofS
            # if it is cos items
            else:
                indexofStart = indexofC
            # print(MODE)
            if MODE == "FAST":
                newEqu = newEqu + item[0:indexofStart] + "*np." + item[indexofStart:indexofStart+4] + "np.deg2rad(" + item[indexofStart+4:-1] + ", dtype=np.longdouble), dtype=np.longdouble)"
            else:
                newEqu = newEqu + item[0:indexofStart] + "*array_" + item[indexofStart:indexofStart+4] + "array_radians(" + item[indexofStart+4:-1] + "))"
        else:
            if MODE == "FAST":
                newEqu = newEqu + item[0] + "np." + item[1:5] + "np.deg2rad(" + item[5:-1] + ", dtype=np.longdouble), dtype=np.longdouble)"
            else:
                newEqu = newEqu + item[0] + "array_" + item[1:5] + "array_radians(" + item[5:-1] + "))"
    # print(newEqu)
    print("There are {} items".format(count))
    return newEqu

def findLinearEqu(equItem):
    newEqu = equItem
    return newEqu
    
def plot(backfor=None):
    global xStart, xEnd, yStart, yEnd, colorList, colorPickerList, memoryIdx
    global canvasTK, checkboxList, dev, db_con, gridOn, memoryList, window, fram2
    array_sin = np.frompyfunc(gp.sin, 1, 1)
    array_cos = np.frompyfunc(gp.cos, 1, 1)
    array_radians = np.frompyfunc(gp.radians, 1, 1)
    window.config(cursor="wait")
    window.update()
    plt.close()
    for widget in fram2.winfo_children():
        widget.destroy()
    fig, ax = plt.subplots()
    ax.ticklabel_format(useOffset=False)
    fig.set_size_inches(12,8)
    # plt.figure(figsize=(12, 8))
    # fig.set_size_inches(6,4)
    xStartInt = float(xStart.get())
    xEndInt = float(xEnd.get())
    yStartInt = float(yStart.get())
    yEndInt = float(yEnd.get())
    # delta = 0.25
    small_number = gp.mpz(1)
    xrange = np.arange(xStartInt, xEndInt, (xEndInt-xStartInt)/NUMBER_OF_POINTS)
    yrange = np.arange(yStartInt, yEndInt, (yEndInt-yStartInt)/NUMBER_OF_POINTS)
    # xrange = np.arange(xStartInt, xEndInt, (xEndInt-xStartInt)/50, dtype=np.longdouble)
    # yrange = np.arange(yStartInt, yEndInt, (yEndInt-yStartInt)/50, dtype=np.longdouble)
    x, y = np.meshgrid(xrange, yrange)
    if MODE == "FAST":
        pass
    else:
        x = x/gp.mpfr(1)
        y = y/gp.mpfr(1)
    # x = torch.from_numpy(xnp)
    # y = torch.from_numpy(ynp)
    # x = x.to(dev)
    # y = y.to(dev)
    npEquList = []
    opeList = []

    for idx, inputItem in enumerate(inputList):
        if (idx in checkedIndexs):
            npEquList.append("")
            opeList.append("")
            continue
        data0 = inputItem.get().strip()
        if len(data0) == 0:
            npEquList.append("")
            continue
        if data0.find("=") != -1:
            if representsFloat(data0[:data0.find("=")]):
                equItem = data0.split("=")[1]
                numberItem = data0.split("=")[0]
            else:
                equItem = data0.split("=")[0]
                numberItem = data0.split("=")[1]
            opeList.append("=")
        elif data0.find("<") != -1:
            if representsFloat(data0[:data0.find("<")]):
                opeList.append(">")
                equItem = data0.split("<")[1]
                numberItem = data0.split("<")[0]
            else:
                opeList.append("<")
                equItem = data0.split("<")[0]
                numberItem = data0.split("<")[1]
        elif data0.find(">") != -1:
            if representsFloat(data0[:data0.find(">")]):
                opeList.append("<")
                equItem = data0.split(">")[1]
                numberItem = data0.split(">")[0]
            else:
                opeList.append(">")
                equItem = data0.split(">")[0]
                numberItem = data0.split(">")[1]
        else:
            equItem = data0
            opeList.append("=")
            numberItem = "0"
        if equItem[0] != "+" and equItem[0] != "-":
            equItem = "+" + equItem
        # print(equItem)
        if equItem.find("sin") >= 0:
            cosSinMatchings = re.finditer(r'[+-]\d*?sin\((.*?)\)', equItem)
            newEqu = findCosSinEqu(cosSinMatchings)
        elif equItem.find("cos") >= 0:
            cosSinMatchings = re.finditer(r'[+-]\d*?cos\((.*?)\)', equItem)
            newEqu = findCosSinEqu(cosSinMatchings)
        else:
            newEqu = findLinearEqu(equItem)
        newEqu += "-(" + numberItem + ")"
        npEquList.append(newEqu)
    evalStart = time.time()
    for index, newEqu in enumerate(npEquList):
        # print(newEqu)
        if newEqu == "":
            continue
        cur = db_con.cursor()
        # Create table
        cur.execute("SELECT result FROM equations WHERE torchequ=? AND xlow=? AND xhigh=? AND ylow=? AND yhigh=? AND mode=? AND numpoint=? AND precision=? ", 
                    (newEqu,xStartInt, xEndInt, yStartInt, yEndInt, MODE, NUMBER_OF_POINTS, PRECISION))
        db_result = cur.fetchone()
        if db_result:
            cur.execute('''UPDATE equations
                            SET addtime = ?
                            WHERE torchequ=? AND xlow=? AND xhigh=? AND ylow=? AND yhigh=? AND mode=? AND numpoint=? AND precision=?
                        ''',
                        (datetime.datetime.now(), newEqu,xStartInt, xEndInt, yStartInt, yEndInt, MODE, NUMBER_OF_POINTS, PRECISION))
            npEqu = db_result[0]
            # print(npEqu)
        else:
            npEqu = eval(newEqu)
            # npEqu = npEqu.to("cpu").numpy()
            # print(npEqu)
            cur.execute("INSERT INTO equations (torchequ, xlow, xhigh, ylow, yhigh, result, addtime, mode, numpoint, precision) values (?,?,?,?,?,?,?,?,?,?)", 
                        (newEqu, xStartInt, xEndInt, yStartInt, yEndInt, npEqu,datetime.datetime.now(), MODE, NUMBER_OF_POINTS, PRECISION))
        db_con.commit()
        # equations = [np.sin(x + 3*y)]
        # print(npEqu)
        if opeList[index] == "<":
            plt.contourf(x, y, npEqu,[0], colors=canvasTK.itemcget(colorPickerList[index], "fill"),levels = [-10000, 0], alpha=0.6)
            plt.contour(x, y, npEqu,[0], colors=canvasTK.itemcget(colorPickerList[index], "fill"), linestyles="dashed")        
        elif opeList[index] == ">":
            plt.contourf(x, y, npEqu,[0], colors=canvasTK.itemcget(colorPickerList[index], "fill"),levels = [0, 10000], alpha=0.6)
            plt.contour(x, y, npEqu,[0], colors=canvasTK.itemcget(colorPickerList[index], "fill"), linestyles="dashed")
        else:
            plt.contour(x, y, npEqu,[0], colors=canvasTK.itemcget(colorPickerList[index], "fill"))
        # print(npEqu)
    evalEnd = time.time()
    print("drawing time: " + str(evalEnd - evalStart))
    newLoc = Location(xStartInt, xEndInt, yStartInt, yEndInt)
    if ((memoryIdx >= 0 and memoryList[memoryIdx] != newLoc) or memoryIdx == -1) and backfor == None:
        memoryList = memoryList[:memoryIdx+1]
        memoryList.append(newLoc)
        memoryIdx += 1


    # for equation in equations:
        # plt.contour(x, y, equation, [0])
  # 0=sin(x+y)
    # ax.autoscale()
    plt.xlim([xStartInt, xEndInt])
    plt.ylim([yStartInt, yEndInt])
    ax.tick_params(axis="x", direction="in", width=2.5, color="red")
    ax.tick_params(axis='y', direction="in", width=2.5, color='red')

    if gridOn:    
        ax.grid(which='major', color='#CCCCCC', linestyle='--')
        ax.grid(which='minor', color='#CCCCCC', linestyle=':')
        ax.axhline(y=0, lw=1.5, color='k', linestyle='--', alpha=0.6)
        ax.axvline(x=0, lw=1.5, color='k', linestyle='--', alpha=0.6)
    # plt.ticklabel_format(style='plain', axis='x', scilimits=(0,0))
    plt.minorticks_on()
    connection_id = fig.canvas.mpl_connect('button_press_event', onclick)
    # creating the Tkinter canvas
    # containing the Matplotlib figure
    canvas = FigureCanvasTkAgg(fig,
                               master = fram2)  
    canvas.draw()

    xlabels = ax.get_xticklabels()
    xticks = [*ax.xaxis.get_major_ticks()]
    counter = 0
    for idx, tick in enumerate(xticks):
        old_label_text = xlabels[idx].get_text().replace('−', '-')
        d = decimal.Decimal(old_label_text)
        exponent = d.as_tuple().exponent
        if counter % 2 != 0 and exponent < -5:
            tick.set_pad(15)
        counter += 1

    ylabels = ax.get_yticklabels()
    yticks = [*ax.yaxis.get_major_ticks()]
    ytick_list = ax.get_yticks().tolist()
    counter = 0
    new_y_labels = []
    for idx, tick in enumerate(yticks):
        old_label_text = ylabels[idx].get_text().replace('−', '-')
        d = decimal.Decimal(old_label_text)
        exponent = d.as_tuple().exponent
        if (exponent < -8):
            new_label = '\n'.join(wrap(old_label_text, 8))
            # print(new_label)
            tick=new_label
            ytick_list[idx] = new_label
            ax.set_yticklabels(ytick_list)
        else:
            new_y_labels.append(old_label_text)
    # placing the canvas on the Tkinter window
    canvas.get_tk_widget().pack()
    # creating the Matplotlib toolbar
    toolbar = NavigationToolbar2Tk(canvas,
                                   fram2)
    toolbar.update()
    # placing the toolbar on the Tkinter window
    canvas.get_tk_widget().pack()
    window.config(cursor="")

def pick_color(event, yLocation):
    global initialInputY, colorList, canvasTK
    inputIndex = int((yLocation - initialInputY)/35)
    color_code = colorchooser.askcolor(color=colorList[inputIndex], title ="Choose color")
    if color_code[1] == None:
        return
    # colorList[inputIndex] = color_code[1]
    canvasTK.itemconfig(colorPickerList[inputIndex], fill=color_code[1])
    plot()
    return

def delete_equation(yLocation):
    global inputList, deleteBtnList, nextInputY, initialInputY, colorPickerList, canvasTK, checkboxList, checkedVarList
    inputIndex = int((yLocation - initialInputY)/35)
    canvasTK.delete(colorPickerList[inputIndex])
    colorPickerList.pop(inputIndex)
    for i in range(inputIndex, len(colorPickerList)):
        canvasTK.move(colorPickerList[i], 0, -35)
    inputList[inputIndex].destroy()
    inputList.pop(inputIndex)
    deleteBtnList[inputIndex].destroy()
    deleteBtnList.pop(inputIndex)
    checkboxList[inputIndex].destroy()
    checkboxList.pop(inputIndex)
    checkedVarList.pop(inputIndex)
    for idx, equation in enumerate(inputList):
        equation.place(x=5, y=initialInputY+idx*35)

    for idx, btn in enumerate(deleteBtnList):
        btn.place(x=200, y=initialInputY+idx*35)
        btn['command'] = lambda arg1=initialInputY+idx*35 : delete_equation(arg1)

    for idx, checkbox in enumerate(checkboxList):
        checkbox.place(x=290, y=initialInputY+idx*35)
        checkbox['command'] = lambda arg1=checkedVarList[idx], arg2=initialInputY+idx*35+5: checked(arg1, arg2)

    nextInputY = initialInputY + 35*(len(deleteBtnList))
    initEntry.place(x=5, y=nextInputY)
    plot()
    return

def checked(value, yPos):
    global checkedIndexs
    checkIndex = int((yPos-initialInputY)/35)
    # print(checkedIndexs)
    if value.get() == 0:
        # print("after uncheck value: " + str(value.get()))
        checkedIndexs.add(checkIndex)
    else:
        # print("after check value: " + str(value.get()))
        checkedIndexs.remove(checkIndex)
    # print(checkedIndexs)
    plot()
    return

def restore():
    global xStart, xEnd, yStart, yEnd
    xStart = set_text(xStart, 0.0)
    xEnd = set_text(xEnd, 90.0)
    yStart = set_text(yStart, 0.0)
    yEnd = set_text(yEnd, 90.0)
    plot()

def zoomin():
    global xStart, xEnd, yStart, yEnd, ratioInput
    xStartFloat = float(xStart.get())
    xEndFloat = float(xEnd.get())
    yStartFloat = float(yStart.get())
    yEndFloat = float(yEnd.get())
    ratio = float(ratioInput.get())
    centerZoom((xEndFloat + xStartFloat)/(2*gp.mpfr(1)), (yEndFloat + yStartFloat)/(2*gp.mpfr(1)), ratio, "in")
    plot()

def zoomout():
    global xStart, xEnd, yStart, yEnd, ratioInput
    xStartFloat = float(xStart.get())
    xEndFloat = float(xEnd.get())
    yStartFloat = float(yStart.get())
    yEndFloat = float(yEnd.get())
    ratio = float(ratioInput.get())
    centerZoom((xEndFloat + xStartFloat)/(2*gp.mpfr(1)), (yEndFloat + yStartFloat)/(2*gp.mpfr(1)), ratio, "out")
    plot()

def add_equation(fromStart=False):
    global nextInputY, initEntry, inputList, deleteBtnList, window, checkboxList, checkedVarList
    global canvasTK, colorList, initialInputY, colorPickerList, colorIndex, checkedIndexs
    # new delete button
    newDelete = Button(fram1, text = "Delete")
    newDelete.place(x=200, y=nextInputY, width=50, height=30)
    newDelete['command'] = lambda arg1=nextInputY : delete_equation(arg1)
    deleteBtnList.append(newDelete)
    # draw color picker
    newOval = canvasTK.create_oval(245, nextInputY, 275, nextInputY+30, 
        fill=colorList[colorIndex%len(colorList)], outline="#DDD", width=2)
    colorIndex+=1
    canvasTK.tag_bind(newOval, "<ButtonPress-1>", lambda event, arg=nextInputY: pick_color(event, arg))
    colorPickerList.append(newOval)
    # hidden checkbox
    newVal = tk.IntVar()
    newVal.set(1)
    newCheck = tk.Checkbutton(window, text='', variable=newVal, command=(lambda arg1=newVal, arg2=nextInputY+5: checked(arg1, arg2)))
    newCheck.place(x=290, y=nextInputY+5)
    newCheck.select()
    checkboxList.append(newCheck)
    checkedVarList.append(newVal)
    # checkedIndexs.add(int((nextInputY-120)/35))
    # new entry
    nextInputY+=35
    newEntry = Entry(fram1, bg="white", fg="black", insertbackground="black")
    newEntry.place(x=5, y=nextInputY, width=150, height=30)
    inputList.append(initEntry)
    initEntry = newEntry
    if not fromStart:
        plot()
    return

def on_closing():
    global db_con, xStart, xEnd, yStart, yEnd, inputList, ratioInput, limitInput
    try:
        with open('temp.txt', 'w') as f:
            f.truncate(0)
            f.write("{}\n{}\n{}\n{}\n".format(xStart.get(), xEnd.get(), yStart.get(), yEnd.get()))
            f.write("{}\n{}\n".format(ratioInput.get(), limitInput.get()))
            for idx, inputItem in enumerate(inputList):
                f.write("{}\n".format(inputItem.get()))
    except Exception as e:
        print(e)
    db_con.close()
    window.destroy()
    sys.exit()

def clearEqu():
    global initialInputY, inputList
    inputListSize = len(inputList)
    for idx in range(inputListSize):
        delete_equation(initialInputY)
    plot()
    return

def change_limit(a,b,c):
    global limitInput, LIMIT
    LIMIT = int(limitInput.get())
    sys.setrecursionlimit(LIMIT)
    print(LIMIT)

def grid_on():
    global gridOn
    gridOn = True
    plot()

def grid_off():
    global gridOn
    gridOn = False
    plot()

def fast_on():
    global MODE, mode_str
    mode_str.set('Mode: FAST')
    MODE = "FAST"
    plot()

def slow_on():
    global MODE, mode_str
    mode_str.set('Mode: SLOW')
    MODE = "SLOW"
    plot()

def backwardMem():
    global memoryIdx, memoryList, xStart, xEnd, yStart, yEnd
    if memoryIdx <= 0 or len(memoryList) == 0:
        return
    memoryIdx -= 1
    backLoc = memoryList[memoryIdx]
    xStart = set_text(xStart, backLoc.xStart)
    xEnd = set_text(xEnd, backLoc.xEnd)
    yStart = set_text(yStart, backLoc.yStart)
    yEnd = set_text(yEnd, backLoc.yEnd)
    plot(True)
    
def forwardMem():
    global memoryIdx, memoryList, xStart, xEnd, yStart, yEnd
    if memoryIdx >= len(memoryList) - 1 or len(memoryList) == 0:
        return
    memoryIdx += 1
    backLoc = memoryList[memoryIdx]
    xStart = set_text(xStart, backLoc.xStart)
    xEnd = set_text(xEnd, backLoc.xEnd)
    yStart = set_text(yStart, backLoc.yStart)
    yEnd = set_text(yEnd, backLoc.yEnd)
    plot(True)

def restore_data():
    global xStart, xEnd, yStart, yEnd, inputList, ratioInput, limitInput, initEntry
    '''
    order: xstart, xend, ystart, yend, ration, limit, equations
    '''
    with open('temp.txt') as f:
        lines = [line.strip() for line in f]
    if (len(lines) < 6):
        return
    xStart = set_text(xStart, lines[0])
    xEnd = set_text(xEnd, lines[1])
    yStart = set_text(yStart, lines[2])
    yEnd = set_text(yEnd, lines[3])
    ratioInput = set_text(ratioInput, lines[4])
    limitStr.set(lines[5])
    if (len(lines) > 6):
        # print("in")
        lines = lines[6:]
        for equ in lines:
            initEntry = set_text(initEntry, equ)
            add_equation(True)
        # plot()
    return

if torch.cuda.is_available():  
    dev = "cuda:0" 
# elif torch.backends.mps.is_available():
#     dev = "mps"
else:  
    dev = "cpu"  
print(dev)
current_path = os.path.dirname(os.path.abspath(__file__))
fetchNumberPoints(current_path + "/NumberOfPoints.txt")
sys.setrecursionlimit(LIMIT)
db_con = create_db()
equationDict = {}
initialInputY = 190
nextInputY = 190
checkedIndexs = set()
inputList = []
deleteBtnList = []
colorList = ["#000000", "#0000FF", "#986657", "#00FFFF", "#00FF00", "#FF00FF", "#FFA500" ,"#A020F0", "#FF0000", "#FFFF00"]
colorPickerList = []
checkboxList = []
checkedVarList = []
memoryList = []
memoryIdx = -1
colorIndex = 0
gridOn = True
randomFunc = lambda: random.randint(0,255)
# for i in range(20):
#     color = '#%02X%02X%02X' % (randomFunc(),randomFunc(),randomFunc())
#     colorList.append(color)
# The main tkinter window
window = Tk()
window.protocol("WM_DELETE_WINDOW", on_closing)
# setting the title and 
window.title('Plotting in Tkinter')
# setting the dimensions of 
# the main window
window.geometry("1500x900")

def donothing():
    return 
menubar = Menu(window)
filemenu = Menu(menubar, tearoff=0)
filemenu.add_command(label="New", command=donothing)
panedwindow=PanedWindow(window, orient=HORIZONTAL)  
panedwindow.pack(fill=BOTH, expand=1)
fram1=Frame(panedwindow, width=320,relief="raised")
fram2=Frame(panedwindow, width=1200,relief="raised", bg="grey")
panedwindow.add(fram1)
panedwindow.add(fram2)
fram1.pack_propagate(0)
fram2.pack_propagate(0)


canvasTK = tk.Canvas(fram1, borderwidth=0, highlightthickness=0,
                   bg="systemWindowBackgroundColor", width=300, height=2000)

# canvas = tk.Canvas(fram1, borderwidth=0, highlightthickness=0,
#                    bg="white", width=300, height=2000)
canvasTK.pack()

# button that would displays the plot
Button(master = fram1, command = plot,
                     text = "Replot").place(x=5,y=5, width=100, height=30)

Button(master=fram1, command=zoomin, 
                    text = "+").place(x=250,y=5, width=30, height=30)
Button(master=fram1, command=zoomout, 
                    text = "-").place(x=285,y=5, width=30, height=30)
Button(master=fram1, command=restore, 
                    text = "restore").place(x=185,y=5, width=60, height=30)
# plot_button.pack()
# place the button
# into the window
# fram1.add(plot_button)

# myscrollbar=Scrollbar(window,orient="vertical")
# myscrollbar.pack(side="right",fill="y")

Button(master = fram1, command = clearEqu,
                     text = "Clear").place(x=5,y=40, width=50, height=30)

Button(master = fram1, command = backwardMem,
                     text = "Backward").place(x=50,y=40, width=70, height=30)

Button(master = fram1, command = forwardMem,
                     text = "Forward").place(x=120,y=40, width=70, height=30)

Button(master=fram1, command=grid_on, 
                    text = "Grid ON").place(x=185,y=40, width=60, height=30)

Button(master=fram1, command=grid_off, 
                    text = "Grid OFF").place(x=250,y=40, width=65, height=30)

xStart = Entry(fram1, bg="white", fg="black", insertbackground="black")
xEnd = Entry(fram1, bg="white", fg="black", insertbackground="black")
yStart = Entry(fram1, bg="white", fg="black", insertbackground="black")
yEnd = Entry(fram1, bg="white", fg="black", insertbackground="black")
xStart.insert(END, '0.00')
xEnd.insert(END, '90.00')
yStart.insert(END, '0.00')
yEnd.insert(END, '90.00')

xStart.place(x=5, y=80, width=55, height=30)
xEnd.place(x=100, y=80, width=55, height=30)
yStart.place(x=5, y=115, width=55, height=30)
yEnd.place(x=100, y=115, width=55, height=30)
Label(fram1,text = "≤x≤", font=("Arial", 16)).place(x = 60, y = 85) 
Label(fram1,text = "≤y≤", font=("Arial", 16)).place(x = 60, y = 120)

Label(fram1,text = "ratio:", font=("Arial", 16)).place(x = 195, y = 80)
ratioInput = Entry(fram1, bg="white", fg="black", insertbackground="black")
ratioInput.insert(END, '2.00')
ratioInput.place(x=250, y=80, width=60, height=30)

Label(fram1,text = "limit:", font=("Arial", 16)).place(x = 195, y = 115)
limitStr = StringVar()
limitStr.set('20000')
limitInput = Entry(fram1, bg="white", textvariable=limitStr, fg="black", insertbackground="black")
limitInput.place(x=250, y=115, width=60, height=30)
limitStr.trace('w', change_limit)

Button(master=fram1, command=fast_on, 
                    text = "Fast ON").place(x=5,y=155, width=60, height=30)

Button(master=fram1, command=slow_on, 
                    text = "Slow ON").place(x=70,y=155, width=65, height=30)

mode_str = StringVar()
mode_str.set('Mode: FAST')
mode_label = Label(fram1,textvariable=mode_str , font=("Arial", 16)).place(x = 140, y = 155)

initEntry = Entry(fram1, bg="white", fg="black", insertbackground="black")
initEntry.place(x=5, y=nextInputY, width=150, height=30)
Button(master = fram1, command = add_equation,
                     text = "Add").place(x=160,y=nextInputY, width=35, height=30)

# Entry(window).place(x=5, y=40)
# Entry(window).place(x=5, y=80)
restore_data()
# run the gui
window.mainloop()