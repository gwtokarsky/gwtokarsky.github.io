# A Better Desmos Calculator
## The purpuse of this calculator
Usually, we used some online calculators such as desmos, mathematica and symbolab to calculate and graph a long and complex sine-cosine equations. 

However, most of them don't support a very long equation(Usually they should be able to support longer equations, but they have to use some strategies to limit the users' useage).

In order to understand the complex equations better, we decided to design and implement a local calcualtor which uses the local CPU/GPU to graph the equations.

## Project structure and lib dependencies
### Source code
The calcualtor only has two source code files, one is `torch_test.py`, another is `location.py`. `torch_test` has the main logic of the program, and `location` is a class which contains some attributes about x and y range.

### Database
In this project, I used sqlite database as the cache for the recent calculation result. Since the db size grows very fast as complex the equations becomes, you can set a limit for the db, it will clean some old data after that limit. Right now the limit is 100mb.

### Temp file
temp.txt is a file which stores the status before the program's last off.

### Libraries
- Numpy is used for fast scientific calculation.
- Pytorch is used to enable GPU booster for the calculation.
- mpmath enables to adjust the number of decimals supported by the program.
- tkinter provides a GUI feature for the project.

## Some features of the projects
### How many sum of sines or cosines it can graph?
Python has a recursionlimit which limits the number of recusions in one program's run. That's for the reason of program safety(prevent dead loop bug). By increase this value, the calculator can graph infinite sines and coines theoretically.

But I set it to 20000 as default for now, in order to keep the safety of the program. The user can change it in either UI or source code.

### How many decimals it can discern before it goes away?
After introducing the library `mpmath`, the program now supports infinite numbers of decimals. However, the useage of mpmath will cause the significantly slow speed. I will talk about the speed in the later benchmark section. Although the calculation result supports infinite numbers of decimals, the graphing library Matplotlib seems only support 14 decimal precision. More investigation should be done on that.

### How it is better than desmos?
As I described above, this calculator has no limit for the length of sine-cosine equations, and it also has no limit for the decimals. For the online desmos calculator, it has limits for both length and precision.

### GPU booster
GPU booster is enabled and supports 64 bits in some architectures right now. Maybe combine mpmath with Pytorch in the future can give a better performance.

### Database cache
Because it takes a long time to calculate the equations, we have a database which stores the recent calculation data. In the second time you draw the same equation, it only takes less than 0.5 sec to draw.

### What others could use it for?
People can use it to see the shapes of sine-cosine equations, the area of inequality, the intersections of multiple equations, and find some interesting patterns in the trig equation graphs.

## How it works
1. After getting the x,y ranges, it uses np.arange and np.meshgrid to get a lot of random points in that range.
2. Then using numpy or mpmath's sin and cos functions to apply the random points to the equations.
   - Using numpy will make it faster and using mpmath will make it more precise
3. Drop x, y and result in the last step into the function plt.contour and it will use the `Marching squares` algorithm to draw the graph.

## Improvements in future
### What it lacks that desmos has?
- Although this calculator has no limit for length and precision. It will take much longer time to graph when the decimial is high and the equation is long compared with desmos. See details in the benchmark section.
- Unlike the desmos, you can not drag to move the graph in this calculator. If you want to move the graph, you need to enter the new x, y ranges and click `replot` button.
- It doesn't suppor the degree now, it doesn't support the degree/radian convert either.
- It can only draw sine/cosine equations and very simple linear equations such as `y=3*x+5`. Desmos supports various types of equations.
- It doesn't support the real-time parse and calculation. After you change some value of equation or x and y, you need to click `replot` to draw it.

### What features it could use to make it better?
- Optimize and improve the speed will increase the user experience significantly.
- After the speed is satisfiable, drag and move feature can be implemented.
- Add degree/radian conver suppor is helpful.
- Change hard code to some more intelligent parse can support more types of equations.
- Implement the real-time parse is helpful.
- The input box of equations can be replaced by some better ui component to give a better view of whole equation.
- GPU booster such as Pytorch doesn't support some architectures and high decimals right now. More investigation can be made to enable the the booster for high decimals(more than 64 bits) and different system architectures. This [code](https://github.com/minyoungkim21/vmf-lib/blob/main/models.py) may help.
- Right now the ui doesn't support scrollbar for the equation list. A scrollbar enables more equations.

### Codebase
Currently, the code is very messy and isn't very pythonic. Some potential suggestions include:
- Use more classes in the code. For example, a class called `Equation` which has equation text itself, its color and the calculation result.
- Reorganize the function, some function can be combined or seprated.
- Refactor the whole code when it's necessary.

## Benchmark
### 1 item: 0=sin(3x)
|                | number of points |      50    |    200      |    1000    |
| -------------- | ---------------- | ---------- | ----------- | ---------- |
| mpmath decimal |                  |            |             |            |
| 15(default)    |                  | 0.0029 sec | 0.0040 sec  | 0.0317 sec |
| 32             |                  | 0.0098 sec | 0.1117 sec  | 2.5879 sec |
| 64             |                  | 0.0113 sec | 0.1335 sec  | 3.1955 sec |
| 128            |                  | 0.0240 sec | 0.1606 sec  | 3.6204 sec |

### 100 item: 0=sin(3x) + ...(98) + sin(4x+5y)
|                | number of points |      50    |    200      |    1000    |
| -------------- | ---------------- | ---------- | ----------- | ---------- |
| mpmath decimal |                  |            |             |            |
| 15(default)    |                  | 0.0079 sec | 0.0374 sec  | 0.8930 sec |
| 32             |                  | 0.5476 sec | 8.7001 sec  | 222.29 sec |
| 64             |                  | 0.7128 sec | 11.349 sec  | 283.91 sec |
| 128            |                  | 0.8101 sec | 12.646 sec  | 319.57 sec |

### 3000 item: 0=sin(3x) + ...(2998) + sin(4x+5y)
|                | number of points |     50     |    200      |    1000    |
| -------------- | ---------------- | ---------- | ----------- | ---------- |
| mpmath decimal |                  |            |             |            |
| 15(default)    |                  | 0.0929 sec | 0.8403 sec  | 25.839 sec |
| 32             |                  | 16.536 sec | 253.52 sec  | ~ 112 mins |
| 64             |                  | 20.915 sec | 332.34 sec  | > 120 mins |
| 128            |                  | 24.009 sec | 378.48 sec  | > 120 mins |