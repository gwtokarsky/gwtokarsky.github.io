class Location:
    def __init__(self, xStart, xEnd, yStart, yEnd):
        self.xStart = xStart
        self.xEnd = xEnd
        self.yStart = yStart
        self.yEnd = yEnd

    def __eq__(self, other): 
        if not isinstance(other, Location):
            # don't attempt to compare against unrelated types
            return False

        return (self.xStart == other.xStart and self.xEnd == other.xEnd 
                and self.yStart == other.yStart and self.yEnd == other.yEnd)
